package beemobi.webapp.service;

import beemobi.webapp.dao.entity.User;

public interface VerifyService {
    String generateLoginToken(String username);

    User verifyLoginToken(String token);
}
