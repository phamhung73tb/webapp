package beemobi.webapp.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import utility.ObjectValidator;

public abstract class AbstractService {

    protected ObjectValidator validator;
}
