package beemobi.webapp.service.impl;

import beemobi.webapp.dao.entity.User;
import beemobi.webapp.dao.repository.UserRepository;
import beemobi.webapp.dto.LoginResponse;
import beemobi.webapp.dto.RequestLogin;
import beemobi.webapp.exception.RequestParamInvalidException;
import beemobi.webapp.exception.ResourceNotFoundException;
import beemobi.webapp.service.AbstractService;
import beemobi.webapp.service.LoginService;
import java.util.Optional;
import lombok.RequiredArgsConstructor;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Service;

@Service
@RequiredArgsConstructor
public class LoginServiceImpl extends AbstractService implements LoginService {

    private final UserRepository userRepository;

    private final VerifyServiceImpl tokenProvider;
    @Override
    public Optional<LoginResponse> login(RequestLogin requestLogin) {
        String message = validator.validateRequestThenReturnMessage(requestLogin);

        if (!StringUtils.isEmpty(message)) {
            throw new RequestParamInvalidException(message);
        }

        User user = userRepository.findByUsernameAndPassword(
        requestLogin.getUsername(), requestLogin.getPassword())
            .orElseThrow(() -> {
                throw new ResourceNotFoundException();
            });

        Optional<User> userData = Optional.of(user);
        return userData.map(userLogin -> new LoginResponse(userLogin.getUsername(),
            userLogin.getPassword(),
            tokenProvider.generateLoginToken(requestLogin.getUsername())));
    }
}
