package beemobi.webapp.service;

import beemobi.webapp.dto.LoginResponse;
import beemobi.webapp.dto.RequestLogin;
import java.util.Optional;

public interface LoginService {
    Optional<LoginResponse> login(RequestLogin requestLogin);
}
