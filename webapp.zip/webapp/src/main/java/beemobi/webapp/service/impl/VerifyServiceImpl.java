package beemobi.webapp.service.impl;

import beemobi.webapp.dao.entity.User;
import beemobi.webapp.dao.repository.UserRepository;
import beemobi.webapp.exception.TokenInvalidException;
import beemobi.webapp.service.AbstractService;
import beemobi.webapp.service.VerifyService;
import io.jsonwebtoken.Claims;
import io.jsonwebtoken.ExpiredJwtException;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.SignatureAlgorithm;
import java.util.Date;
import java.util.Optional;
import lombok.NonNull;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import utility.DateTimeUtils;

@Service
@RequiredArgsConstructor
public class VerifyServiceImpl extends AbstractService implements VerifyService {

    private final UserRepository userRepository;

    @Value("${token.expiration}")
    private Integer tokenExpiredValue;

    @Value("${token.key}")
    private String tokenKeyValue;

    @Override
    public String generateLoginToken(String username) {
        return Jwts.builder()
            .setSubject(username)
            .setIssuedAt(new Date())
            .setExpiration(DateTimeUtils.addDayToDate(new Date(), tokenExpiredValue))
            .signWith(SignatureAlgorithm.HS256, tokenKeyValue.getBytes())
            .compact();
    }

    @Override
    public @NonNull User verifyLoginToken(@NonNull String token) {
        String username;

        try {
            Claims claims = Jwts.parser()
                .setSigningKey(tokenKeyValue.getBytes())
                .parseClaimsJws(token)
                .getBody();

            username = claims.getSubject();
        } catch (ExpiredJwtException e) {
            throw new TokenInvalidException("E1", "Token is Expired");
        } catch (Exception e) {
            throw new TokenInvalidException("E2", "Can not verify token");
        }

        Optional<User> user = userRepository.findById(username);
        return user.orElseThrow(() -> {
            throw new TokenInvalidException("E3", "This user is invalidate: " + username);
        });
    }
}
