package beemobi.webapp.constants;

public class DateTime {
    public static final String YYYY_MM_DD_HH_MM_SS_HYPHEN = "yyyy-MM-dd HH:mm:ss";

    public static final String YYYY_MM_DD_HH_MM_SS_SLASH = "yyyy/MM/dd HH:mm:ss";

    public static final String YYYY_MM_DD_SLASH = "yyyy/MM/dd";
}
