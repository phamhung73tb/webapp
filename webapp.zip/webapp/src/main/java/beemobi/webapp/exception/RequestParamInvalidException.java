package beemobi.webapp.exception;

public class RequestParamInvalidException extends RuntimeException{
    public RequestParamInvalidException(String message) {
        super(message);
    }
}
