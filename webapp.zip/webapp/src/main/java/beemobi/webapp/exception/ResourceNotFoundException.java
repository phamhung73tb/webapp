package beemobi.webapp.exception;

public class ResourceNotFoundException extends RuntimeException{

}
