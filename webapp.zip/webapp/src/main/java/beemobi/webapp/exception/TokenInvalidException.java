package beemobi.webapp.exception;

import lombok.Data;
import lombok.EqualsAndHashCode;

@EqualsAndHashCode(callSuper = true)
@Data
public class TokenInvalidException extends RuntimeException{
    private String code;

    public TokenInvalidException(String message, String code) {
        super(message);
        this.code = code;
    }
}
